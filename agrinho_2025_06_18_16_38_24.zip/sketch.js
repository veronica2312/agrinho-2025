let player;
let items = [];
let itemTypes = ['campo', 'cidade'];
let scoreCampo = 0;
let scoreCidade = 0;

function setup() {
  createCanvas(600, 400);
  player = new Player();
  // Cria alguns itens iniciais
  for (let i = 0; i < 15; i++) {
    items.push(new Item());
  }
  textSize(16);
  textAlign(LEFT, TOP);
}

function draw() {
  background(220);

  // Desenha o jogador
  player.show();
  player.move();

  // Atualiza e desenha itens
  for (let i = items.length - 1; i >= 0; i--) {
    items[i].show();
    if (player.catchItem(items[i])) {
      // Atualiza pontuação
      if (items[i].type === 'campo') {
        scoreCampo++;
        showMessage("Conexão com o campo fortalecida!", color(34, 139, 34));
      } else {
        scoreCidade++;
        showMessage("A cidade se conecta ao campo!", color(70, 130, 180));
      }
      // Remove o item coletado
      items.splice(i, 1);
      // Cria um novo item
      items.push(new Item());
    }
  }

  // Mostrar pontuação
  fill(0);
  noStroke();
  text(`Campo: ${scoreCampo}`, 10, 40);
  text(`Cidade: ${scoreCidade}`, 10, 40);
}

// Classe do jogador
class Player {
  constructor() {
    this.x = width / 4;
    this.y = height - 50;
    this.size = 30;
    this.speed = 5;
  }

  show() {
    fill(255, 215, 10);
    ellipse(this.x, this.y, this.size);
  }

  move() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= this.speed;
    }
    if (keyIsDown(RIGHT_ARROW)) {
      this.x += this.speed;
    }
    if (keyIsDown(UP_ARROW)) {
      this.y -= this.speed;
    }
    if (keyIsDown(DOWN_ARROW)) {
      this.y += this.speed;
    }
    // Limites da tela
    this.x = constrain(this.x, 0, width);
    this.y = constrain(this.y, 0, height);
  }

  catchItem(item) {
    let d = dist(this.x, this.y, item.x, item.y);
    return d < (this.size / 2 + item.size / 2);
  }
}

// Classe dos itens
class Item {
  constructor() {
    this.x = random(20, width - 20);
    this.y = random(50, height - 50);
    this.size = 20;
    this.type = random(itemTypes);
    this.color = this.type === 'campo' ? color(34, 1139, 34) : color(70, 130, 180);
  }

  show() {
    fill(this.color);
    noStroke();
    rectMode(CENTER);
    rect(this.x, this.y, this.size, this.size);
    // Opcional: desenhar detalhes diferentes para cada tipo
    if (this.type === 'campo') {
      fill(255, 0, 0);
      ellipse(this.x, this.y, this.size / 2);
    } else {
      fill(255, 255, 0);
      triangle(this.x - 5, this.y + 5, this.x + 5, this.y + 5, this.x, this.y - 5);
    }
  }
}

// Variável para mensagens temporárias
let message = '';
let messageColor;
let messageTimer = 0;

function showMessage(msg, col) {
  message = msg;
  messageColor = col;
  messageTimer = 60; // dura aproximadamente 1 segundo
}

function draw() {
  background(220);

  // Desenha o jogador
  player.show();
  player.move();

  // Atualiza e desenha itens
  for (let i = items.length - 1; i >= 0; i--) {
    items[i].show();
    if (player.catchItem(items[i])) {
      if (items[i].type === 'campo') {
        scoreCampo++;
        showMessage("Conexão com o campo fortalecida!", color(34, 139, 34));
      } else {
        scoreCidade++;
        showMessage("A cidade se conecta ao campo!", color(70, 130, 180));
      }
      // Remove o item coletado
      items.splice(i, 1);
      // Cria um novo item
      items.push(new Item());
    }
  }

  // Mostrar pontuação
  fill(0);
  noStroke();
  text(`Campo: ${scoreCampo}`, 10, 10);
  text(`Cidade: ${scoreCidade}`, 10, 40);

  // Mostrar mensagem temporária
  if (messageTimer > 0) {
    fill(messageColor);
    textSize(20);
    textAlign(CENTER, CENTER);
    text(message, width / 2, height / 2);
    messageTimer--;
  }
}
